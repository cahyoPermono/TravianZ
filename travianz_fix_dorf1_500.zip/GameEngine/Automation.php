<?php

#################################################################################
##              -= YOU MAY NOT REMOVE OR CHANGE THIS NOTICE =-                 ##
## --------------------------------------------------------------------------- ##
##  Filename       : Automation.php                      	                   ##
##  Type           : Automation Function for entire TravianZ Game              ##
## --------------------------------------------------------------------------- ##
##  Developed by   : Mr.php , Advocaite , brainiacX , yi12345 , Shadow , ronix ##
##  Refactored by  : Shadow & Ferywir									       ##
##  Thanks to      : InCube, Akakori, Elmar & Kirilloid                        ##
##  Split&Refactor : Shadow													   ##
##  Phase S2       : Methods split into 11 traits (GameEngine/Automation/)     ##
## --------------------------------------------------------------------------- ##
##  Contact        : cata7007@gmail.com                                        ##
##  Project        : TravianZ                                                  ##
##  URLs:          : https://travianz.org                                      ##
##  GitHub         : https://github.com/Shadowss/TravianZ                      ##
## --------------------------------------------------------------------------- ##
##  License        : TravianZ Project                                          ##
##  Copyright      : TravianZ (c) 2010-2026. All rights reserved.              ##
## --------------------------------------------------------------------------- ##
#################################################################################

// make sure we only run the automation script once and wait until it's done,
// so concurrent AJAX calls from many different users won't overload the server
if ( !defined('AUTOMATION_MANUAL_RUN') ) {
    if(defined('AUTOMATION_LOCK_FILE_NAME')){
        if ( file_exists( AUTOMATION_LOCK_FILE_NAME ) ) {
            // check that the file is not too old, in which case our PHP script hung
            // and we need to remove the lock and run automation again
            $fileTime = filemtime( AUTOMATION_LOCK_FILE_NAME );
    
            // allow for 60 seconds of old automation script processing time, which is still way too plenty
            if ( ! $fileTime || time() - $fileTime > 60 ) {
                @unlink( AUTOMATION_LOCK_FILE_NAME );
            } else {
                // automation file exists and is valid, don't run another automation
                exit;
            }
        } else {
            // create automation lock file
            file_put_contents( AUTOMATION_LOCK_FILE_NAME, '' );
        }
    }
}

/**
 * Automation.php presupunea ca apelantul a inclus deja config.php. Cand nu era
 * asa (de exemplu inclus din alt context), Database.php dadea eroare fatala:
 *   Undefined constant "SQL_SERVER"
 *
 * Il incarcam noi daca lipseste. include_once nu-l aduce de doua ori.
 */
if (!defined('SQL_SERVER')) {
    $automationConfig = __DIR__ . '/config.php';

    if (is_file($automationConfig)) {
        include_once($automationConfig);
    } elseif (is_file(__DIR__ . '/../config.php')) {
        include_once(__DIR__ . '/../config.php');
    }
}

include_once("Database.php");
include_once("Data/buidata.php");
include_once("Data/unitdata.php");
include_once("Data/hero_full.php");
include_once("Data/cp.php");
include_once("Units.php");
include_once("Battle.php");
include_once("AllianceBonus.php");
include_once("Technology.php");
include_once("Ranking.php");
include_once("Generator.php");
include_once("Multisort.php");
include_once("Building.php");
include_once("Artifacts.php");

// === Faza S2: clasa Automation este impartita in trait-uri pe domenii (GameEngine/Automation/) ===
// Trait-urile sunt in namespace global, deci sunt incluse explicit (autoloaderul mapeaza doar App\).
include_once __DIR__ . '/Automation/AutomationVillageUpkeep.php';
include_once __DIR__ . '/Automation/AutomationAccountMaintenance.php';
include_once __DIR__ . '/Automation/AutomationBuildQueue.php';
include_once __DIR__ . '/Automation/AutomationMarket.php';
include_once __DIR__ . '/Automation/AutomationBattleResolution.php';
include_once __DIR__ . '/Automation/AutomationTroopMovements.php';
include_once __DIR__ . '/Automation/AutomationTraining.php';
include_once __DIR__ . '/Automation/AutomationHero.php';
include_once __DIR__ . '/Automation/AutomationStarvation.php';
include_once __DIR__ . '/Automation/AutomationNatarsWW.php';
include_once __DIR__ . '/Automation/AutomationNatarsWWBuild.php';
include_once __DIR__ . '/Automation/AutomationMedals.php';
include_once __DIR__ . '/Automation/AutomationCleanup.php';
include_once __DIR__ . '/Automation/AutomationPlayerStatistics.php';

class Automation {
    // === Faza S2: metodele clasei, grupate pe domenii ===
    use AutomationVillageUpkeep;
    use AutomationAccountMaintenance;
    use AutomationBuildQueue;
    use AutomationMarket;
    use AutomationBattleResolution;
    use AutomationTroopMovements;
    use AutomationTraining;
    use AutomationHero;
    use AutomationStarvation;
    use AutomationNatarsWW;
    use AutomationNatarsWWBuild;
    use AutomationMedals;



    use AutomationCleanup;
    use AutomationPlayerStatistics;
    /**
     * @var object The artifacts class, used to create Natars, artifacts and obtaining info about them
     */
    
    private $artifacts;
    
    /**
     * Cache pentru utilizatori pentru a reduce query-urile duplicate
     * @var array
     */
    private $userCache = [];
    
    public function __construct() {
    	
        //Classes initialization
        $this->artifacts = new Artifacts();
        
    	$autoprefix = "";
    	for ($i = 0; $i < 5; $i++) {
    		$autoprefix = str_repeat('../', $i);
    		if (file_exists($autoprefix.'autoloader.php')) {
    			// we have our path, let's leave
    			break;
    		}
    	}
    	
        $this->procNewClimbers();
        $this->ClearUser();
        $this->pruneResource();
        $this->pruneOResource();
        $this->checkWWAttacks();
        $this->delTradeRoute();
        $this->TradeRoute();
        
        $methodsArrays = ["culturePoints", "updateHero", "clearDeleting", "buildComplete",
        				  "demolitionComplete", "marketComplete", "researchComplete",
        				  "trainingComplete", "healingComplete", "starvation", "celebrationComplete", "festivalComplete",
        				  "sendUnitsComplete", "loyaltyRegeneration", "sendreinfunitsComplete",
        				  "returnunitsComplete", "sendSettlersComplete", "spawnNatars",
        				  "spawnWWVillages", "spawnWWBuildingPlans", "activateArtifacts",
        				  "heroAdventureComplete",
        				  "cleanupOldData",
        				  "recordPlayerStatistics",
					  "buildNatarsWonder"];
        
        foreach($methodsArrays as $method){
        	$filePath = $autoprefix."GameEngine/Prevention/".$method.".txt";
        	$file = @fopen($filePath, "w");
        	if($file !== false) {
        		if(@flock($file, LOCK_EX)) {
        			try {
        				call_user_func(array($this, $method));
        			} catch (\Throwable $e) {
        				error_log("Automation method $method error: " . $e->getMessage());
        			}
        			@flock($file, LOCK_UN);     		
        		}
        		@fclose($file);
        	} else {
        		try {
        			call_user_func(array($this, $method));
        		} catch (\Throwable $e) {
        			error_log("Automation method $method error: " . $e->getMessage());
        		}
        	}
        }
        
        try {
            $this->MasterBuilder();
            $this->updateGeneralAttack();
            $this->checkInvitedPlayes();
            $this->updateStore();

            // Finalizeaza upgrade-urile de bonus de alianta ajunse la termen.
            if (class_exists('AllianceBonus') && AllianceBonus::enabled()) {
                $allianceBonus = new AllianceBonus();
                $allianceBonus->processUpgrades();
            }
            $this->CheckBan();
            $this->regenerateOasisTroops();
            $this->medals();
            $this->artefactOfTheFool();
        } catch (\Throwable $e) {
            error_log("Automation upkeep error: " . $e->getMessage());
        }

        // Bot AI: Automated building, training, and early-game raiding
        if (defined('BOT_AI_ENABLED') && BOT_AI_ENABLED) {
            try {
                require_once __DIR__ . '/BotAI.php';
                BotAI::run();
            } catch (\Throwable $e) {
                error_log("BotAI error: " . $e->getMessage());
            }
        }

        // PvE Bandit Camps & World Boss: Maintain active camps on map
        if (defined('BANDIT_CAMPS_ENABLED') && BANDIT_CAMPS_ENABLED) {
            try {
                require_once __DIR__ . '/BanditCamp.php';
                BanditCamp::run();
            } catch (\Throwable $e) {
                error_log("BanditCamp error: " . $e->getMessage());
            }
        }

        // Dynamic Weather & Plague cycle processing
        if (defined('WEATHER_SYSTEM_ENABLED') && WEATHER_SYSTEM_ENABLED) {
            try {
                require_once __DIR__ . '/Weather.php';
                Weather::tick();
            } catch (\Throwable $e) {
                error_log("Weather error: " . $e->getMessage());
            }
        }
        if (defined('PLAGUE_SYSTEM_ENABLED') && PLAGUE_SYSTEM_ENABLED) {
            try {
                require_once __DIR__ . '/Plague.php';
                Plague::tick();
            } catch (\Throwable $e) {
                error_log("Plague error: " . $e->getMessage());
            }
        }
    }

    /**
     * Retrieve user data using local cache.
    **/
	
    private function getCachedUser($uid, $mode = 1) {
        global $database;
        $uid = (int)$uid;
        if (!isset($this->userCache[$uid])) {
            $this->userCache[$uid] = $database->getUserArray($uid, $mode);
        }
        return $this->userCache[$uid];
    }
}
$automation = new Automation;

// remove automation lock file
@unlink( AUTOMATION_LOCK_FILE_NAME );
?>
