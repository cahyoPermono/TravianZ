<?php
include_once("GameEngine/Generator.php");
$start_timer = $generator->pageLoadTimeStart();

#################################################################################
##              -= YOU MAY NOT REMOVE OR CHANGE THIS NOTICE =-                 ##
## --------------------------------------------------------------------------- ##
##  Filename       : berucgte.php                      	                       ##
##  Type           : In Game Messages Page                                     ##
## --------------------------------------------------------------------------- ##
##  Developed by   : yi12345					                               ##
##  Refactored by  : Shadow                                                    ##
##  Redesign by    : Shadow                                                    ##
## --------------------------------------------------------------------------- ##
##  Contact        : cata7007@gmail.com                                        ##
##  Project        : TravianZ                                                  ##
##  URLs:          : https://travianz.org                                      ##
##  GitHub         : https://github.com/Shadowss/TravianZ                      ##
## --------------------------------------------------------------------------- ##
##  License        : TravianZ Project                                          ##
##  Copyright      : TravianZ (c) 2010-2026. All rights reserved.              ##
## --------------------------------------------------------------------------- ##
#################################################################################

use App\Utils\AccessLogger;

include_once("GameEngine/Village.php");
AccessLogger::logRequest();

$message->noticeType($_GET);
$message->procNotice($_POST);
if(isset($_GET['newdid'])) {
	$_SESSION['wid'] = $_GET['newdid'];
    if ( isset( $_GET['t'] ) ) {
        header( "Location: " . $_SERVER['PHP_SELF'] . "?t=" . $_GET['t'] );
        exit;
    } else if ( isset( $_GET['vill'] ) && isset( $_GET['id'] ) ) {
        header( "Location: " . $_SERVER['PHP_SELF'] . "?id=" . $_GET['id'] . "&vill=" . $_GET['vill'] . "" );
        exit;
    } else if ( isset($_GET['id']) && $_GET['id'] != 0 ) {
        header( "Location: " . $_SERVER['PHP_SELF'] . "?id=" . $_GET['id'] );
        exit;
    } else {
        header( "Location: " . $_SERVER['PHP_SELF'] );
        exit;
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<title><?php echo SERVER_NAME ?> - <?php echo REPORTS ?></title>
	<link rel="shortcut icon" href="favicon.ico"/>
	<meta http-equiv="cache-control" content="max-age=0" />
	<meta http-equiv="pragma" content="no-cache" />
	<meta http-equiv="expires" content="0" />
	<meta http-equiv="imagetoolbar" content="no" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<script src="mt-full.js?0faab" type="text/javascript"></script>
	<script src="unx.js?f4b7h" type="text/javascript"></script>
	<script src="new.js?0faab" type="text/javascript"></script>
	<link href="<?php echo GP_LOCATE; ?>lang/en/lang.css?f4b7d" rel="stylesheet" type="text/css" />
	<link href="<?php echo GP_LOCATE; ?>lang/en/compact.css?f4b7i" rel="stylesheet" type="text/css" />
	<link href="css/mobile_engine.css?v=20261009_m2" rel="stylesheet" type="text/css" />
	<?php
	// GP_LOCATE contine deja pachetul efectiv: alegerea jucatorului cand
	// e permisa si valida, altfel pachetul serverului (vezi config.php).
	echo "
	<link href='".GP_LOCATE."travian.css?e21d2' rel='stylesheet' type='text/css' />
	<link href='".GP_LOCATE."lang/en/lang.css?e21d2' rel='stylesheet' type='text/css' />";
	?>
	<script type="text/javascript">

		window.addEvent('domready', start);
	</script>
</head>


<body class="v35 ie ie8">
<div class="wrapper">
<img style="filter:chroma();" src="img/x.gif" id="msfilter" alt="" />
<div id="dynamic_header">
	</div>
<?php include("Templates/header.tpl"); ?>
<div id="mid">
<?php include("Templates/menu.tpl"); ?>
		<div id="content"  class="reports">
<h1><?php echo REPORTS; ?></h1>
<div id="textmenu">
   <a href="berichte.php" <?php if (!isset($_GET['t'])) { echo "class=\"selected \""; } ?>><?php echo ALL; ?></a>
 | <a href="berichte.php?t=2" <?php if (isset($_GET['t']) && $_GET['t'] == 2) { echo "class=\"selected \""; } ?>><?php echo TZ_TRADE; ?></a>
 | <a href="berichte.php?t=1" <?php if (isset($_GET['t']) && $_GET['t'] == 1) { echo "class=\"selected \""; } ?>><?php echo REINFORCEMENT; ?></a>
 | <a href="berichte.php?t=3" <?php if (isset($_GET['t']) && $_GET['t'] == 3) { echo "class=\"selected \""; } ?>><?php echo TZ_ATTACKS; ?></a>
 | <a href="berichte.php?t=4" <?php if (isset($_GET['t']) && $_GET['t'] == 4) { echo "class=\"selected \""; } ?>><?php echo TZ_MISCELLANEOUS; ?></a>
 <?php if($session->plus) {
 echo "| <a href=\"berichte.php?t=5\"";
 if (isset($_GET['t']) && $_GET['t'] == 5) { echo "class=\"selected \""; }
 echo ">".ARCHIVE."</a>";
 }
 ?>
</div>

<?php
/**
 * Buton "Read All" (cerut de Catalin): marcheaza dintr-un click toate
 * rapoartele necitite ca citite, indiferent de tab/pagina curenta - fara
 * sa mai fie nevoie sa deschizi fiecare raport pe rand. Vizibil doar cand
 * exista ceva necitit ($message->nunread, calculat deja in constructorul
 * Message). Trimite POST catre acelasi Message::procNotice() care trateaza
 * deja del_x/archive_x/start_x mai sus in acest fisier (linia 31).
 */
if ($message->nunread > 0) {
    echo '<div id="textmenu" class="rpt-readall">';
    echo '<form method="post" action="berichte.php" style="display:inline;">';
    echo '<button type="submit" name="readall" value="1" class="rpt-readall-btn">';
    echo htmlspecialchars(READ_ALL_REPORTS, ENT_QUOTES, 'UTF-8');
    echo '</button>';
    echo '</form>';
    echo '</div>';
}
?>
<?php
/**
 * Filtru dupa rezultat, doar in categoria de atacuri.
 *
 * Rapoartele de alianta aveau deja acest filtru; cele personale nu. Informatia
 * exista deja in ntype, deci nu e nevoie de nicio schimbare in baza de date
 * (vezi Message::noticeType).
 */
if (isset($_GET['t']) && (int) $_GET['t'] === 3) {

    $rptFilters = array(
        0 => defined('TZ_RPT_ALL_RESULTS') ? TZ_RPT_ALL_RESULTS : 'All',
        1 => defined('TZ_RPT_F_WON_NOLOSS') ? TZ_RPT_F_WON_NOLOSS : 'Won without losses',
        2 => defined('TZ_RPT_F_WON_LOSS') ? TZ_RPT_F_WON_LOSS : 'Won with losses',
        3 => defined('TZ_RPT_F_LOST') ? TZ_RPT_F_LOST : 'Lost',
    );

    $rptCurrent = isset($_GET['f']) ? (int) $_GET['f'] : 0;

    echo '<div id="textmenu" class="rpt-result-filter">';

    foreach ($rptFilters as $rptVal => $rptLabel) {
        if ($rptVal > 0) {
            echo ' | ';
        }

        $rptHref = 'berichte.php?t=3' . ($rptVal > 0 ? '&amp;f=' . $rptVal : '');

        echo '<a href="' . $rptHref . '"'
           . ($rptCurrent === $rptVal ? ' class="selected "' : '')
           . '>' . htmlspecialchars($rptLabel, ENT_QUOTES, 'UTF-8') . '</a>';
    }

    echo '</div>';
}
?>
<?php
if (isset($_GET['id'])) 
{
    $tzShareEligible = false;

    if (isset($_GET['aid']) && $_GET['aid'] > 0 && $_GET['aid'] == $session->alliance && $database->getNotice2($_GET['id'], 'ally') == $session->alliance)
    {
        $type = $database->getNotice2($_GET['id'], 'ntype');
        if ($type >= 10 && $type <= 17) unset($type);
    }
    elseif(isset($_GET['vill']) && $database->getNotice2($_GET['id'], 'ally') == $session->alliance)
    {
        $type = $database->getNotice2($_GET['id'], 'ntype');
        if ($type >= 10 && $type <= 17) unset($type);
    }
    elseif($database->getNotice2(preg_replace("/[^a-zA-Z0-9_-]/", "", $_GET['id']), 'uid') == $session->uid) 
    {
        $type = ($message->readingNotice['ntype'] == 9) ? $message->readingNotice['archive'] : $message->readingNotice['ntype'];

        // Faza 3 Global Chat (09.09.2026): doar proprietarul vazand propriul
        // raport poate primi butonul de distribuire, si doar rapoarte de
        // LUPTA - atac SAU aparare (cand te ataca altcineva pe tine, raportul
        // TAU are tot un ntype din acelasi set - t=3/TZ_ATTACKS din
        // Message::noticeType() include deja ambele roluri). Verificam ntype-ul
        // ORIGINAL, nefiltrat (nu $type, care mai sus poate fi deja remapat pe
        // arhiva). Tine sincron cu $shareableNtypes din
        // Database::shareGlobalChatReport().
        $tzShareableNtypes = [1, 2, 3, 4, 5, 6, 7, 22, 23];
        $tzOwnNtype = $message->readingNotice['ntype'] ?? null;
        if ($tzOwnNtype !== null && in_array((int) $tzOwnNtype, $tzShareableNtypes, true)) {
            $tzShareEligible = true;
        }
    }
    elseif ($database->isGlobalChatSharedReport($_GET['id']))
    {
        // Faza 3 Global Chat (09.09.2026): raport distribuit explicit in
        // chat-ul general de catre proprietarul lui - vizibil oricui e logat,
        // indiferent de alianta. Acelasi filtru de siguranta ca la share-ul
        // de alianta mai sus (10-17 raman ascunse), desi in practica
        // Database::shareGlobalChatReport() deja refuza sa distribuie orice
        // in afara de ntype 1-7 - dublam verificarea aici din prudenta.
        $type = $database->getNotice2($_GET['id'], 'ntype');
        if ($type >= 10 && $type <= 17) unset($type);
    }
    
    if(isset($type)) include("Templates/Notice/".$message->getReportType($type).".tpl");

    // Faza 3 Global Chat: butonul "Distribuie in chat", doar cand eligibil (vezi mai sus)
    if ($tzShareEligible) {
        include("Templates/GlobalChat/share_report_button.tpl");
    }

    unset($type);
}
else include("Templates/Notice/all.tpl");
?>
</div>

<br /><br /><br /><br /><div id="side_info">
<?php
include("Templates/multivillage.tpl");
include("Templates/quest.tpl");
include("Templates/news.tpl");
if(!NEW_FUNCTIONS_DISPLAY_LINKS) {
	echo "<br><br><br><br>";
	include("Templates/links.tpl");
}
?>
</div>
<div class="clear"></div>
</div>
<div class="footer-stopper"></div>
<div class="clear"></div>

<?php
include("Templates/footer.tpl");
include("Templates/res.tpl");
?>
<div id="stime">
<div id="ltime">
<div id="ltimeWrap">
<?php echo CALCULATED_IN;?> <b><?php
echo round(($generator->pageLoadTimeEnd()-$start_timer)*1000);
?></b> ms

<br /><?php echo SERVER_TIME;?> <span id="tp1" class="b"><?php echo date('H:i:s'); ?></span>
</div>
	</div>
</div>

<div id="ce"></div>
</body>
</html>
