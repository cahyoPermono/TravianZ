<?php

#################################################################################
##              -= YOU MAY NOT REMOVE OR CHANGE THIS NOTICE =-                 ##
## --------------------------------------------------------------------------- ##
##  Filename       : tutorial.php                      	                       ##
##  Type           : In Game Tutorial Page                                     ##
## --------------------------------------------------------------------------- ##
##  Developed by   : Dzoki 						                               ##
##  Refactored by  : Shadow                                                    ##
##  Redesign by    : Shadow                                                    ##
## --------------------------------------------------------------------------- ##
##  Contact        : cata7007@gmail.com                                        ##
##  Project        : TravianZ                                                  ##
##  URLs:          : https://travianz.org                                      ##
##  GitHub         : https://github.com/Shadowss/TravianZ                      ##
## --------------------------------------------------------------------------- ##
##  License        : TravianZ Project                                          ##
##  Copyright      : TravianZ (c) 2010-2026. All rights reserved.              ##
## --------------------------------------------------------------------------- ##
#################################################################################

use App\Utils\AccessLogger;

include_once("GameEngine/config.php");
include_once("GameEngine/Database.php");
require_once __DIR__ . "/GameEngine/Lang/loader.php";
tz_load_language(LANG);
AccessLogger::logRequest();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?php echo SERVER_NAME; ?></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="stylesheet" type="text/css" href="img/tutorial/main.css"/>
	<link rel="stylesheet" type="text/css" href="img/tutorial/flaggs.css"/>
	<link rel="stylesheet" type="text/css" href="css/mobile_engine.css?v=20261009_m2"/>
	<meta name="content-language" content="en"/>
	<meta http-equiv="imagetoolbar" content="no"/>
	<script src="mt-core.js" type="text/javascript"></script>
	<script src="new.js" type="text/javascript"></script>
	<style type="text/css" media="screen">

	</style>
</head>
<body class="webkit contentPage">
<div class="wrapper">
<div id="country_select">
</div>
<div id="header">
	<h1><?php echo PUBLIC_WELCOME_TO; ?> <?php echo SERVER_NAME; ?></h1>
</div>
<div id="navigation">
<a href="index.php" class="home"><img src="img/x.gif" alt="Travian"/></a>
	<table class="menu">
	<tr>
		<td><a href="tutorial.php"><span><?php echo TUTORIAL; ?></span></a></td>
		<td><a href="anleitung.php"><span><?php echo PUBLIC_MANUAL; ?></span></a></td>
		<td><a href="http://forum.travian.com/" target="_blank"><span><?php echo FORUM; ?></span></a></td>
		<td><a href="index.php?signup"><span><?php echo PUBLIC_REGISTER; ?></span></a></td>
		<td><a href="index.php?login"><span><?php echo LOGIN; ?></span></a></td>
</tr>
	</table>
</div>
<div id="content">
<div class="grit">
<h1><?php echo TUTORIAL; ?></h1>
					<?php
						if(!isset($_GET['s'])) {
						$_GET['s'] = ""; }
						if ($_GET['s'] == "") {
						include("Templates/Tutorial/1.tpl"); }
						if ($_GET['s'] == "1") {
						include("Templates/Tutorial/1.tpl"); }
						if ($_GET['s'] == "2") {
						include("Templates/Tutorial/2.tpl"); }
						if ($_GET['s'] == "3") {
						include("Templates/Tutorial/3.tpl"); }
						if ($_GET['s'] == "4") {
						include("Templates/Tutorial/4.tpl"); }
						if ($_GET['s'] == "5") {
						include("Templates/Tutorial/5.tpl"); }
					?>
</ul>
<div class="footer"></div>
</div>
</div>
<div id="iframe_layer" class="overlay">
<div class="mask closer"></div>
<div class="overlay_content">
<a href="index.php" class="closer"><img class="dynamic_img" alt="<?php echo PUBLIC_CLOSE; ?>" src="img/un/x.gif" /></a>
<h2><?php echo PUBLIC_MANUAL; ?></h2>
<div id="frame_box" >
</div>
<div class="footer"></div>
</div>
</div>
</body>
</html>
