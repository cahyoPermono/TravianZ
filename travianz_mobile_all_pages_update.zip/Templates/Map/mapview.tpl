<?php

#################################################################################
##              -= YOU MAY NOT REMOVE OR CHANGE THIS NOTICE =-                 ##
## --------------------------------------------------------------------------- ##
##  Filename       : mapview.tpl                        	                   ##
##  Type           : Karte Map Scroll Small Backend                            ##
## --------------------------------------------------------------------------- ##
##  Developed by   : Dzoki & Advocaite & Donnchadh                             ##
##  Refactored by  : Shadow & Ferywir									       ##
##  Redesign by    : Shadow                                                    ##
## --------------------------------------------------------------------------- ##
##  Contact        : cata7007@gmail.com                                        ##
##  Project        : TravianZ                                                  ##
##  URLs:          : https://travianz.org                                      ##
##  GitHub         : https://github.com/Shadowss/TravianZ                      ##
## --------------------------------------------------------------------------- ##
##  License        : TravianZ Project                                          ##
##  Copyright      : TravianZ (c) 2010-2026. All rights reserved.              ##
## --------------------------------------------------------------------------- ##
#################################################################################

/* =========================
   WORLD CONFIG SHORTCUT
========================= */
$W = WORLD_MAX;

/* =========================
   COORDINATE INPUT HANDLING
========================= */
if (isset($_GET['z'])) {

    $currentcoor = $database->getCoor($_GET['z']);
    $y = $currentcoor['y'];
    $x = $currentcoor['x'];
    $bigmid = $_GET['z'];

} else if(isset($_POST['xp']) && isset($_POST['yp'])) {

    $x = $_POST['xp'];
    $y = $_POST['yp'];
    $bigmid = $generator->getBaseID($x, $y);

} else {

    $y = $village->coor['y'];
    $x = $village->coor['x'];
    $bigmid = $village->wid;
}

/* =========================
   RESET MOVEMENTS CACHE
========================= */
if (isset($_SESSION['troops_movement'])) {
    unset($_SESSION['troops_movement']);
}

/* =========================
   PLUS ACCOUNT ATTACK DATA
========================= */
if ($session->plus) {
    $session->populateAttacks();
}

/* =========================
   MAP COORDINATES CALCULATION
   (kept behavior identical)
========================= */
$xm7 = ($x - 7) < -$W ? $x + $W + $W - 6 : $x - 7;
$xm3 = ($x - 3) < -$W ? $x + $W + $W - 2 : $x - 3;
$xm2 = ($x - 2) < -$W ? $x + $W + $W - 1 : $x - 2;
$xm1 = ($x - 1) < -$W ? $x + $W + $W : $x - 1;

$xp1 = ($x + 1) > $W ? $x - $W - $W : $x + 1;
$xp2 = ($x + 2) > $W ? $x - $W - $W + 1 : $x + 2;
$xp3 = ($x + 3) > $W ? $x - $W - $W + 2 : $x + 3;
$xp7 = ($x + 7) > $W ? $x - $W - $W + 6 : $x + 7;

$ym7 = ($y - 7) < -$W ? $y + $W + $W - 6 : $y - 7;
$ym3 = ($y - 3) < -$W ? $y + $W + $W - 2 : $y - 3;
$ym2 = ($y - 2) < -$W ? $y + $W + $W - 1 : $y - 2;
$ym1 = ($y - 1) < -$W ? $y + $W + $W : $y - 1;

$yp1 = ($y + 1) > $W ? $y - $W - $W : $y + 1;
$yp2 = ($y + 2) > $W ? $y - $W - $W + 1 : $y + 2;
$yp3 = ($y + 3) > $W ? $y - $W - $W + 2 : $y + 3;
$yp7 = ($y + 7) > $W ? $y - $W - $W + 6 : $y + 7;

/* =========================
   MAP GRID ARRAYS
========================= */
$xarray = array($xm3, $xm2, $xm1, $x, $xp1, $xp2, $xp3);
$yarray = array($ym3, $ym2, $ym1, $y, $yp1, $yp2, $yp3);

$maparray = '';
$maparray2 = '';

$xcount = 0;

for ($i = 0; $i <= 6; $i++) {

    if ($xcount != 7) {

        $id = $generator->getBaseID($xarray[$xcount], $yarray[$i]);

        $maparray  .= "'" . $id . "',";
        $maparray2 .= $id . ",";

        if ($i == 6) {
            $i = -1;
            $xcount++;
        }
    }
}

$maparray = substr($maparray, 0, -1);

/* =========================
   MAIN MAP QUERY
   (formatted only, same logic)
========================= */
$query2 = "
SELECT
    " . TB_PREFIX . "wdata.id AS map_id,
    " . TB_PREFIX . "wdata.fieldtype AS map_fieldtype,
    " . TB_PREFIX . "wdata.oasistype AS map_oasis,
    " . TB_PREFIX . "wdata.x AS map_x,
    " . TB_PREFIX . "wdata.y AS map_y,
    " . TB_PREFIX . "wdata.occupied AS map_occupied,
    " . TB_PREFIX . "wdata.image AS map_image,

    " . TB_PREFIX . "odata.conqured AS oasis_conqured,
    info_user_oasis.username AS oasis_user,
    info_user_oasis.tribe AS oasis_tribe,
    info_alliance_oasis.tag AS oasis_alli_name,

    " . TB_PREFIX . "vdata.wref AS ville_id,
    " . TB_PREFIX . "vdata.owner AS ville_user,
    " . TB_PREFIX . "vdata.name AS ville_name,
    " . TB_PREFIX . "vdata.capital AS ville_capital,
    " . TB_PREFIX . "vdata.pop AS ville_pop,

    " . TB_PREFIX . "users.id AS user_id,
    " . TB_PREFIX . "users.username AS user_username,
    " . TB_PREFIX . "users.tribe AS user_tribe,
    " . TB_PREFIX . "users.alliance AS user_alliance,

    " . TB_PREFIX . "alidata.id AS aliance_id,
    " . TB_PREFIX . "alidata.tag AS aliance_name,

    " . TB_PREFIX . "bandit_camps.tier AS bandit_tier,
    " . TB_PREFIX . "bandit_camps.name AS bandit_camp_name

FROM (((((((" . TB_PREFIX . "wdata
    LEFT JOIN " . TB_PREFIX . "vdata ON " . TB_PREFIX . "vdata.wref = " . TB_PREFIX . "wdata.id)
    LEFT JOIN " . TB_PREFIX . "odata ON " . TB_PREFIX . "odata.wref = " . TB_PREFIX . "wdata.id)
    LEFT JOIN " . TB_PREFIX . "users AS info_user_oasis ON info_user_oasis.id = " . TB_PREFIX . "odata.owner)
    LEFT JOIN " . TB_PREFIX . "alidata AS info_alliance_oasis ON info_alliance_oasis.id = info_user_oasis.alliance)
    LEFT JOIN " . TB_PREFIX . "users ON " . TB_PREFIX . "users.id = " . TB_PREFIX . "vdata.owner)
    LEFT JOIN " . TB_PREFIX . "alidata ON " . TB_PREFIX . "alidata.id = " . TB_PREFIX . "users.alliance)
    LEFT JOIN " . TB_PREFIX . "bandit_camps ON (" . TB_PREFIX . "bandit_camps.wref = " . TB_PREFIX . "wdata.id AND " . TB_PREFIX . "bandit_camps.status = 1))

WHERE " . TB_PREFIX . "wdata.id IN ($maparray)
ORDER BY FIND_IN_SET(" . TB_PREFIX . "wdata.id,'$maparray2')
";

$result2 = mysqli_query($database->dblink, $query2) or die(mysqli_error($database->dblink));

/* =========================
   OUTPUT PREPARATION
========================= */
$targetalliance = array();
$neutralarray = array();
$friendarray = array();
$enemyarray = array();

$i = 0;
$i2 = 0;

/* =========================
   COORD ARRAY (STATIC CACHE SAFE)
========================= */

static $coorarray = null;

if ($coorarray === null) {
    $coorarray = array(
        "53, 137, 90, 157, 53, 177, 16, 157",
        "89, 117, 126, 137, 89, 157, 52, 137",
        "125, 97, 162, 117, 125, 137, 88, 117",
        "161, 77, 198, 97, 161, 117, 124, 97",
        "197, 57, 234, 77, 197, 97, 160, 77",
        "233, 37, 270, 57, 233, 77, 196, 57",
        "269, 17, 306, 37, 269, 57, 232, 37",
        "90, 157, 127, 177, 90, 197, 53, 177",
        "126, 137, 163, 157, 126, 177, 89, 157",
        "162, 117, 199, 137, 162, 157, 125, 137",
        "198, 97, 235, 117, 198, 137, 161, 117",
        "234, 77, 271, 97, 234, 117, 197, 97",
        "270, 57, 307, 77, 270, 97, 233, 77",
        "306, 37, 343, 57, 306, 77, 269, 57",
        "127, 177, 164, 197, 127, 217, 90, 197",
        "163, 157, 200, 177, 163, 197, 126, 177",
        "199, 137, 236, 157, 199, 177, 162, 157",
        "235, 117, 272, 137, 235, 157, 198, 137",
        "271, 97, 308, 117, 271, 137, 234, 117",
        "307, 77, 344, 97, 307, 117, 270, 97",
        "343, 57, 380, 77, 343, 97, 306, 77",
        "164, 197, 201, 217, 164, 237, 127, 217",
        "200, 177, 237, 197, 200, 217, 163, 197",
        "236, 157, 273, 177, 236, 197, 199, 177",
        "272, 137, 309, 157, 272, 177, 235, 157",
        "308, 117, 345, 137, 308, 157, 271, 137",
        "344, 97, 381, 117, 344, 137, 307, 117",
        "380, 77, 417, 97, 380, 117, 343, 97",
        "201, 217, 238, 237, 201, 257, 164, 237",
        "237, 197, 274, 217, 237, 237, 200, 217",
        "273, 177, 310, 197, 273, 217, 236, 197",
        "309, 157, 346, 177, 309, 197, 272, 177",
        "345, 137, 382, 157, 345, 177, 308, 157",
        "381, 117, 418, 137, 381, 157, 344, 137",
        "417, 97, 454, 117, 417, 137, 380, 117",
        "238, 237, 275, 257, 238, 277, 201, 257",
        "274, 217, 311, 237, 274, 257, 237, 237",
        "310, 197, 347, 217, 310, 237, 273, 217",
        "346, 177, 383, 197, 346, 217, 309, 197",
        "382, 157, 419, 177, 382, 197, 345, 177",
        "418, 137, 455, 157, 418, 177, 381, 157",
        "454, 117, 491, 137, 454, 157, 417, 137",
        "275, 257, 312, 277, 275, 297, 238, 277",
        "311, 237, 348, 257, 311, 277, 274, 257",
        "347, 217, 384, 237, 347, 257, 310, 237",
        "383, 197, 420, 217, 383, 237, 346, 217",
        "419, 177, 456, 197, 419, 217, 382, 197",
        "455, 157, 492, 177, 455, 197, 418, 177",
        "491, 137, 528, 157, 491, 177, 454, 157"
    );
}

/* =========================
   OUTPUT VARS
========================= */

$yrow = 0;
$row = 0;
$coorindex = 0;

$map_js = '';
$map_gen = '';
$map_content = '';

/* =========================
   MAIN LOOP (UNCHANGED LOGIC)
========================= */
while ($donnees = mysqli_fetch_assoc($result2)) {

    $targetalliance = $donnees["aliance_id"];

	$sessionAlliance = (int)$session->alliance;

	$allyCache = $database->getAllianceAlly($sessionAlliance, 1)?: [];
	$warCache = $database->getAllianceWar2($sessionAlliance)?: [];
	$neutralCache = $database->getAllianceAlly($sessionAlliance, 2)?: [];

	$target = (int)$donnees["aliance_id"];

    /* =========================
       RELATION STATUS
    ========================= */
	
	$friend = $war = $neutral = 0;

	if ($target && $sessionAlliance) {
    foreach ($allyCache as $ac) {
        if ((($ac['alli1']?? 0) == $target) || (($ac['alli2']?? 0) == $target)) { $friend = 1; break; }
    }
    foreach ($warCache as $wc) {
        if ((($wc['alli1']?? 0) == $target) || (($wc['alli2']?? 0) == $target)) { $war = 1; break; }
    }
    foreach ($neutralCache as $nc) {
        if ((($nc['alli1']?? 0) == $target) || (($nc['alli2']?? 0) == $target)) { $neutral = 1; break; }
    }
	}

    /* =========================
       IMAGE DECISION
    ========================= */
    if (!empty($donnees['bandit_tier'])) {
        $bTier = max(1, min(4, (int)$donnees['bandit_tier']));
        $image = 'bandit_t' . $bTier;
    } else {
        $image = ($donnees['map_occupied'] == 1 && $donnees['map_fieldtype'] > 0)
            ? (($donnees['ville_user'] == $session->uid)
                ? ($donnees['ville_pop'] >= 100
                    ? ($donnees['ville_pop'] >= 250
                        ? ($donnees['ville_pop'] >= 500 ? 'b30' : 'b20')
                        : 'b10')
                    : 'b00')
                : (($targetalliance != 0)
                    ? ($friend == 1
                        ? ($donnees['ville_pop'] >= 100
                            ? ($donnees['ville_pop'] >= 250
                                ? ($donnees['ville_pop'] >= 500 ? 'b31' : 'b21')
                                : 'b11')
                            : 'b01')
                        : ($war == 1
                            ? ($donnees['ville_pop'] >= 100
                                ? ($donnees['ville_pop'] >= 250
                                    ? ($donnees['ville_pop'] >= 500 ? 'b32' : 'b22')
                                    : 'b12')
                                : 'b02')
                            : ($neutral == 1
                                ? ($donnees['ville_pop'] >= 100
                                    ? ($donnees['ville_pop'] >= 250
                                        ? ($donnees['ville_pop'] >= 500 ? 'b35' : 'b25')
                                        : 'b15')
                                    : 'b05')
                                : ($targetalliance == $session->alliance
                                    ? ($donnees['ville_pop'] >= 100
                                        ? ($donnees['ville_pop'] >= 250
                                            ? ($donnees['ville_pop'] >= 500 ? 'b33' : 'b23')
                                            : 'b13')
                                        : 'b03')
                                    : ($donnees['ville_pop'] >= 100
                                        ? ($donnees['ville_pop'] >= 250
                                            ? ($donnees['ville_pop'] >= 500 ? 'b34' : 'b24')
                                            : 'b14')
                                        : 'b04')))))
                    : ($donnees['ville_pop'] >= 100
                        ? ($donnees['ville_pop'] >= 250
                            ? ($donnees['ville_pop'] >= 500 ? 'b34' : 'b24')
                            : 'b14')
                        : 'b04')))
            : $donnees['map_image'];
    }

    /* =========================
       ATTACK MARKERS
    ========================= */
    $att = "";

    if (isset($_SESSION['troops_movement'])) {

        if (isset($_SESSION['troops_movement']['attacks']) && in_array($donnees['map_id'], $_SESSION['troops_movement']['attacks'])) {
            $att = '<span class=\'m3\' ></span>';
        } elseif (isset($_SESSION['troops_movement']['scouts']) && in_array($donnees['map_id'], $_SESSION['troops_movement']['scouts'])) {
            $att = '<span class=\'m6\' ></span>';
        } elseif (isset($_SESSION['troops_movement']['enforcements']) && in_array($donnees['map_id'], $_SESSION['troops_movement']['enforcements'])) {
            $att = '<span class=\'m9\' ></span>';
        }
    }

    /* =========================
       MAP CONTENT
    ========================= */
    if ($donnees['ville_user'] == 3 && $donnees['ville_name'] == PLANVILLAGE) {
        $map_content .= "<div id='i_" . $row . "_" . $i . "' class='o99'>$att</div>\r";
    } else {
        $map_content .= "<div id='i_" . $row . "_" . $i . "' class='" . $image . "'>$att</div>\r";
    }

    /* =========================
       AREA GENERATION
    ========================= */
    $displayTitle = !empty($donnees['bandit_camp_name']) ? $donnees['bandit_camp_name'] : $donnees['ville_name'];
    $map_gen .= "<area id='a_" . $row . "_" . $i . "' shape='poly' coords='" . $coorarray[$coorindex] . "' title='" . htmlspecialchars($displayTitle, ENT_QUOTES) . "' href='karte.php?d=" . $donnees['map_id'] . "&c=" . $generator->getMapCheck($donnees['map_id']) . "' />\n";

    /* =========================
       JS MAP DATA
    ========================= */
    if ($yrow != 7) {

        $map_js .= "[" . $donnees['map_x'] . "," . $donnees['map_y'] . "," . $donnees['map_fieldtype'] . "," . ((!empty($donnees['map_oasis'])) ? $donnees['map_oasis'] : 0) . ",\"d=" . $donnees['map_id'] . "&c=" . $generator->getMapCheck($donnees['map_id']) . "\",\"" . $image . "\",\"\"";

        if ($donnees['map_occupied']) {

            if ($donnees['map_fieldtype'] != 0) {
                $jsVillageName = !empty($donnees['bandit_camp_name']) ? addslashes($donnees['bandit_camp_name']) : addslashes($donnees['ville_name']);
                $map_js .= ",\"" . $jsVillageName . "\",\"" . addslashes($donnees['user_username']) . "\",\"" . $donnees['ville_pop'] . "\",\"" . addslashes($donnees['aliance_name']) . "\",\"" . $donnees['user_tribe'] . "\"]\n";
            }

        } elseif ($donnees['map_oasis'] != 0) {

            if ($donnees['oasis_conqured'] != 0) {
                $map_js .= ",\"\",\"" . $donnees['oasis_user'] . "\",\"-\",\"" . $donnees['oasis_alli_name'] . "\",\"" . $donnees['oasis_tribe'] . "\"]";
            } else {
                $map_js .= "]";
            }

        } else {
            $map_js .= "]\n";
        }

        if ($i2 == 6 && $yrow != 6) {
            $i2 = -1;
            $yrow++;
            $map_js .= "],\n[";
        } else {
            $map_js .= ($yrow == 6 && $i2 == 6) ? "]\n" : ",";
        }

    } else {
        $map_js .= "]";
    }

    /* =========================
       LOOP CONTROL
    ========================= */
    if ($i == 6 && $row <= 5) {
        $row++;
        $i = -1;
    }

    $i++;
    $i2++;
    $coorindex++;
}
?>
<style type="text/css">
/* Bandit Camp & World Boss isometric map tiles */
#map_content .bandit_t1, div#map div#map_content div.bandit_t1 {
    background-image: url('img/bandit/tile_tier_1.png?v=<?= file_exists(__DIR__ . "/../../img/bandit/tile_tier_1.png") ? filemtime(__DIR__ . "/../../img/bandit/tile_tier_1.png") : time() ?>') !important;
}
#map_content .bandit_t2, div#map div#map_content div.bandit_t2 {
    background-image: url('img/bandit/tile_tier_2.png?v=<?= file_exists(__DIR__ . "/../../img/bandit/tile_tier_2.png") ? filemtime(__DIR__ . "/../../img/bandit/tile_tier_2.png") : time() ?>') !important;
}
#map_content .bandit_t3, div#map div#map_content div.bandit_t3 {
    background-image: url('img/bandit/tile_tier_3.png?v=<?= file_exists(__DIR__ . "/../../img/bandit/tile_tier_3.png") ? filemtime(__DIR__ . "/../../img/bandit/tile_tier_3.png") : time() ?>') !important;
}
#map_content .bandit_t4, div#map div#map_content div.bandit_t4 {
    background-image: url('img/bandit/tile_tier_4.png?v=<?= file_exists(__DIR__ . "/../../img/bandit/tile_tier_4.png") ? filemtime(__DIR__ . "/../../img/bandit/tile_tier_4.png") : time() ?>') !important;
}
</style>
<div id="content"  class="map">
	<h1><?php echo MAP;?>(<span id="x"><?php echo $x;?></span>|<span id="y"><?php echo $y;?></span>)</h1>
	<div id="map">
		<script type="text/javascript">
			var text_k = {}
			text_k.details = '<?php echo DETAIL;?>';
			text_k.spieler = '<?php echo PLAYER;?>';
			text_k.einwohner = '<?php echo POP;?>';
			text_k.allianz = '<?php echo ALLIANCE;?>';
			text_k.verlassenes_tal = '<?php echo ABANDVALLEY;?>';
			text_k.besetztes_tal = '<?php echo OCCUOASIS;?>';
			text_k.freie_oase = '<?php echo UNOCCUOASIS;?>';
			var text_x = {}
			text_x.r1 = '<?php echo LUMBER;?>';
			text_x.r2 = '<?php echo CLAY;?>';
			text_x.r3 = '<?php echo IRON;?>';
			text_x.r4 = '<?php echo CROP;?>';
		</script>
		<div id="map_canvas_wrap">
			<div id="map_content"><?php echo $map_content;?></div>
			<div id="map_rulers"><?php
				for($i=0;$i<=6;$i++) {
					echo "<div id=\"mx".$i."\">".$xarray[$i]."</div>\n";
					echo "<div id=\"my".$i."\">".$yarray[$i]."</div>\n";
				}?>
			</div>
			<map id="map_overlay" name="map_overlay">
				<?php echo $map_gen;?>
				<area id="ma_n1" href="karte.php?z=<?php echo $generator->getBaseID($x,$yp1);?>" coords="422,67,25" shape="circle" title="<?php echo NORTH;?>"/>
				<area id="ma_n2" href="karte.php?z=<?php echo $generator->getBaseID($xp1,$y);?>" coords="427,254,25" shape="circle" title="<?php echo EAST;?>"/>
				<area id="ma_n3" href="karte.php?z=<?php echo $generator->getBaseID($x,$ym1);?>" coords="119,255,25" shape="circle" title="<?php echo SOUTH;?>"/>
				<area id="ma_n4" href="karte.php?z=<?php echo $generator->getBaseID($xm1,$y);?>" coords="114,63,25" shape="circle" title="<?php echo WEST;?>"/>
			</map>
			<img id="map_links" src="img/x.gif" usemap="#map_overlay" />
		</div>
		<script type="text/javascript">
			m_c.az = {<?php echo '"n1":'.$generator->getBaseID($x,$yp1).',"n1p7":'.$generator->getBaseID($x,$yp7).',"n2":'.$generator->getBaseID($xp1,$y).',"n2p7":'.$generator->getBaseID($xm7,$y).',"n3":'.$generator->getBaseID($x,$ym1).',"n3p7":'.$generator->getBaseID($x,$ym7).',"n4":'.$generator->getBaseID($xm1,$y).',"n4p7":'.$generator->getBaseID($xp7,$y); ?>};
			m_c.ad = [<?php echo '['.$map_js;?>];
			m_c.z = {"x":<?php echo $x ?>,"y":<?php echo $y ?>};
			m_c.size = 7;
			m_c.world_max = <?php echo WORLD_MAX; ?>;
			var mdim = {"x":7,"y":7,"rad":3}
			var mmode = 0;
			function init_local(){map_init();}
		</script><?php
		if($session->plus){
			if(!empty($session->userinfo['map'])){
				// Preference "Show the large map in an extra window" (#198):
				// open the large map (karte2.php) in a separate browser window
				// instead of the in-page iframe overlay.
				echo '<a id="map_makelarge" href="karte2.php?z='.$bigmid.'" target="bigmap" onclick="window.open(this.href, \'bigmap\', \'width=1020,height=600,scrollbars=yes,resizable=yes\'); return false;"><img class="ml" src="img/x.gif" alt="'.LARGE_MAP.'" title="'.LARGE_MAP.'"/></a>';
			} else {
				echo '<a id="map_makelarge" href="#" onclick="PopupMap('.$bigmid.');" ><img class="ml" src="img/x.gif" alt="'.LARGE_MAP.'" title="'.LARGE_MAP.'"/></a>';
			}
		}?>
		<div id="map_controls_row">
			<div id="map_coords">
				<form name="map_coords" method="post" action="karte.php">
					<span>x </span><input id="mcx" class="text" name="xp" value="<?php echo $x ?>" maxlength="4"/>
					<span>y </span><input id="mcy" class="text" name="yp" value="<?php echo $y ?>" maxlength="4"/>
					<input type="image" id="btn_ok" class="dynamic_img" value="ok" name="s1" src="img/x.gif" alt="OK" />
					<?php if($session->goldclub != 0){echo "<a href=\"crop_finder.php\"><img src=\"".GP_LOCATE."img/misc/cropfinder.gif\" /> ".CROPFINDER."</a>";}?>
				</form>
			</div>
			<div id="map_navibox_wrap">
				<img id="map_navibox" src="img/x.gif" usemap="#map_navibox"/>
				<map name="map_navibox">
					<area id="ma_n1p7" href="karte.php?z=<?php echo $generator->getBaseID($x,$yp7) ?>" coords="51,15,73,3,95,15,73,27" shape="poly" title="<?php echo NORTH;?>"/>
					<area id="ma_n2p7" href="karte.php?z=<?php echo $generator->getBaseID($xm7,$y) ?>" coords="51,41,73,29,95,41,73,53" shape="poly" title="<?php echo EAST;?>"/>
					<area id="ma_n3p7" href="karte.php?z=<?php echo $generator->getBaseID($x,$ym7) ?>" coords="4,41,26,29,48,41,26,53" shape="poly" title="<?php echo SOUTH;?>"/>
					<area id="ma_n4p7" href="karte.php?z=<?php echo $generator->getBaseID($xp7,$y) ?>" coords="4,15,26,3,48,15,26,27" shape="poly" title="<?php echo WEST;?>"/>
				</map>
			</div>
		</div>
		<table cellpadding="1" cellspacing="1" id="map_infobox" class="default"><thead><tr><th colspan="2"><?php echo DETAIL;?></th></tr></thead><tbody><tr><th><?php echo PLAYER;?></th><td>-</td></tr><tr><th><?php echo POP;?></th><td>-</td></tr><tr><th><?php echo ALLIANCE;?></th><td></td></tr></tbody></table>
		<script type="text/javascript">
		(function() {
			function initMobileMapEnhancements() {
				var canvasWrap = document.getElementById('map_canvas_wrap');
				var infoBox = document.getElementById('map_infobox');
				if (!canvasWrap || !infoBox) return;

				// Center map scroll horizontally on load
				if (canvasWrap.scrollWidth > canvasWrap.clientWidth) {
					canvasWrap.scrollLeft = Math.round((canvasWrap.scrollWidth - canvasWrap.clientWidth) / 2);
				}

				var activeArea = null;
				var touchStartX = 0, touchStartY = 0, isTouchDragging = false;

				function updateTileAction(area) {
					if (!area || !infoBox) return;
					var tbody = infoBox.querySelector('tbody');
					if (!tbody) return;
					var actionRow = document.getElementById('map_action_row');
					if (!actionRow) {
						actionRow = document.createElement('tr');
						actionRow.id = 'map_action_row';
						actionRow.innerHTML = '<td colspan="2" style="text-align:center; padding: 7px 4px; background: #fdf8eb;"><a id="map_open_btn" href="#" style="display:inline-block; padding: 5px 16px; background: linear-gradient(180deg, #df9b28 0%, #aa6308 100%); color:#fff; font-weight:bold; font-size:12px; border-radius:5px; text-decoration:none; border:1px solid #ffd875; box-shadow:0 1px 3px rgba(0,0,0,0.25);">Buka Tile &#x2794;</a></td>';
						tbody.appendChild(actionRow);
					}
					var btn = document.getElementById('map_open_btn');
					if (btn && area.href) {
						var coords = (area.details && area.details.x !== undefined) ? '(' + area.details.x + '|' + area.details.y + ')' : '';
						btn.href = area.href;
						btn.innerHTML = 'Buka Tile ' + coords + ' &#x2794;';
					}
				}

				// Select center tile (#a_3_3) on load
				var centerTile = document.getElementById('a_3_3');
				if (centerTile && typeof qe === 'function') {
					try {
						qe.call(centerTile);
						activeArea = centerTile;
						updateTileAction(centerTile);
					} catch(e) {}
				}

				canvasWrap.addEventListener('touchstart', function(e) {
					if (e.touches && e.touches.length > 0) {
						touchStartX = e.touches[0].clientX;
						touchStartY = e.touches[0].clientY;
						isTouchDragging = false;
					}
				}, { passive: true });

				canvasWrap.addEventListener('touchmove', function(e) {
					if (e.touches && e.touches.length > 0) {
						var dx = Math.abs(e.touches[0].clientX - touchStartX);
						var dy = Math.abs(e.touches[0].clientY - touchStartY);
						if (dx > 8 || dy > 8) isTouchDragging = true;
					}
				}, { passive: true });

				var mapOverlay = document.getElementById('map_overlay');
				if (mapOverlay) {
					var areas = mapOverlay.getElementsByTagName('area');
					for (var i = 0; i < areas.length; i++) {
						(function(area) {
							if (!area.id || area.id.indexOf('a_') !== 0) return;

							area.addEventListener('click', function(e) {
								if (window.innerWidth <= 860 || ('ontouchstart' in window)) {
									if (isTouchDragging) {
										e.preventDefault();
										return;
									}
									if (activeArea === area) {
										// Second tap on same tile -> follow link
										return;
									} else {
										// First tap on tile -> select and inspect
										e.preventDefault();
										activeArea = area;
										if (typeof qe === 'function') {
											try { qe.call(area); } catch(err) {}
										}
										updateTileAction(area);
									}
								}
							});

							var origMouseOver = area.onmouseover;
							area.onmouseover = function(e) {
								if (origMouseOver) origMouseOver.call(this, e);
								activeArea = area;
								updateTileAction(area);
							};
						})(areas[i]);
					}
				}

				// Prevent 50ms reset on mobile touch
				var origRe = window.re;
				if (typeof origRe === 'function') {
					window.re = function() {
						if (window.innerWidth <= 860 || ('ontouchstart' in window)) {
							return;
						}
						origRe.apply(this, arguments);
					};
				}
			}

			if (document.readyState === 'loading') {
				window.addEventListener('DOMContentLoaded', initMobileMapEnhancements);
			} else {
				setTimeout(initMobileMapEnhancements, 100);
			}
			window.addEventListener('load', function() { setTimeout(initMobileMapEnhancements, 200); });
		})();
		</script>
	</div>            
</div>
